#!/usr/bin/env python3
"""
A simple command‑line toolkit for working with C2PA manifests.

This script supports three primary operations:

  * verify:  Inspect an existing media file and report whether it contains a C2PA
    manifest.  If present, a summary of the manifest's claims and its signature
    status are printed.

  * report:  Produce a detailed JSON representation of the active manifest and
    manifest store contained in a media file.

  * sign:    Attach a new C2PA manifest to a media file.  The manifest is
    defined in a YAML file and signed using an X.509 certificate and private
    key.  The resulting signed file is written to the specified output path.

The implementation uses the `c2pa` Python library.  See the project's README
for installation instructions and more details.

Example usage:

    # Verify whether a file contains a C2PA manifest
    python c2pa_toolkit.py verify path/to/image.jpg

    # Produce a full JSON report of manifest data
    python c2pa_toolkit.py report path/to/video.mp4

    # Sign an image using a manifest definition and certificate/key pair
    python c2pa_toolkit.py sign --input path/to/source.png \
        --output path/to/signed.png \
        --assertions manifest.yml \
        --cert cert.pem --key key.pem

Author: OpenMediaTrust
"""

import argparse
import json
import mimetypes
import os
import sys
from typing import Any, Dict, List, Optional

try:
    import yaml  # type: ignore
except ImportError as exc:
    raise SystemExit(
        "Missing dependency: PyYAML is required. Install with 'pip install PyYAML'"
    ) from exc

# Attempt to import the c2pa library.  If it isn't installed the user will see
# a clear error message rather than a traceback when running commands.
try:
    from c2pa import Builder, Reader, Signer, C2paSignerInfo, C2paSigningAlg  # type: ignore
except ImportError as exc:
    raise SystemExit(
        "Missing dependency: c2pa-python is required. "
        "Install with 'pip install c2pa-python'"
    ) from exc


def _print_error(message: str) -> None:
    """Print an error message to stderr."""
    sys.stderr.write(f"Error: {message}\n")


def verify_media(file_path: str) -> None:
    """
    Verify whether a media file contains a C2PA manifest.

    If a manifest is present the tool prints a high‑level summary including the
    title of the claim, creator (if provided) and the labels of all assertions.
    It also reports the status of the signature validation (valid/invalid).

    If no manifest is present a message is printed indicating such.
    """
    if not os.path.isfile(file_path):
        _print_error(f"No such file: {file_path}")
        return
    try:
        with Reader(file_path) as reader:
            # Parse the manifest store as a Python dictionary
            manifest_store = json.loads(reader.json())
    except Exception as exc:
        _print_error(f"Failed to read manifests: {exc}")
        return

    # Determine the active manifest, if any
    manifests = manifest_store.get("manifests", {})
    active_id = manifest_store.get("active_manifest")
    if not active_id or active_id not in manifests:
        print("No C2PA manifest found.")
        return

    manifest = manifests[active_id]

    # Build a simple summary
    title = manifest.get("title") or "Untitled"
    creator = manifest.get("creator")
    assertions = manifest.get("assertions", [])
    assertion_labels = [a.get("label") for a in assertions if isinstance(a, dict)]

    print("C2PA manifest found.")
    print(f"  Title: {title}")
    if creator:
        print(f"  Creator: {creator}")
    if assertion_labels:
        print("  Assertions:")
        for label in assertion_labels:
            print(f"    • {label}")

    # Validate signature if present
    try:
        validation_status = manifest.get("validation_status")
        if validation_status is not None:
            # The manifest was already validated during reading.
            # A value of `None` or empty dict indicates success.
            if validation_status:
                print("  Signature: invalid (errors detected)")
            else:
                print("  Signature: valid")
        else:
            # Attempt to perform a validation via Reader API.
            # If supported, errors will be raised for invalid signatures.
            # The validate() call returns None on success.
            # Note: c2pa-python may not provide a direct validate() method on Reader,
            # so we attempt to read again to trigger validation.
            with Reader(file_path) as _unused_reader:
                pass
            print("  Signature: valid")
    except Exception:
        # If validation fails the Reader should raise, but this block catches
        # unexpected exceptions and treats them as a validation failure.
        print("  Signature: invalid")


def report_media(file_path: str) -> None:
    """
    Produce a detailed JSON report of the manifest store contained in a media file.

    The JSON is printed with indentation for readability.
    """
    if not os.path.isfile(file_path):
        _print_error(f"No such file: {file_path}")
        return
    try:
        with Reader(file_path) as reader:
            manifest_json = reader.json()
            parsed = json.loads(manifest_json)
            print(json.dumps(parsed, indent=2))
    except Exception as exc:
        _print_error(f"Failed to read manifests: {exc}")


def _load_manifest_yaml(path: str) -> Dict[str, Any]:
    """
    Load a manifest definition from a YAML file.

    The YAML file is expected to define at least an `assertions` list.  Optional
    keys such as `title` and `creator` will be included in the generated manifest.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        raise ValueError("Manifest YAML must define a mapping.")
    return data


def _infer_mime_type(file_path: str) -> str:
    """
    Infer the MIME type for a file based on its extension.

    Defaults to 'application/octet-stream' if no type can be determined.
    """
    mime, _ = mimetypes.guess_type(file_path)
    return mime or "application/octet-stream"


def sign_media(
    input_path: str,
    output_path: str,
    manifest_yaml: str,
    cert_path: str,
    key_path: str,
) -> None:
    """
    Sign a media file by attaching a new manifest.

    The manifest definition is read from a YAML file.  A signer is constructed
    using the provided certificate (PEM) and private key (PEM).  The signed file
    is written to ``output_path``.
    """
    if not os.path.isfile(input_path):
        _print_error(f"No such input file: {input_path}")
        return
    # Load manifest definition
    try:
        manifest_data = _load_manifest_yaml(manifest_yaml)
    except Exception as exc:
        _print_error(f"Failed to load manifest YAML: {exc}")
        return

    title = manifest_data.get("title")
    creator = manifest_data.get("creator")
    assertions = manifest_data.get("assertions", [])
    if not isinstance(assertions, list):
        _print_error("Manifest YAML must contain an 'assertions' list.")
        return

    # Convert YAML assertions into the format expected by the c2pa library:
    # each assertion is an object with a 'label' and a 'data' field.
    converted_assertions: List[Dict[str, Any]] = []
    for item in assertions:
        if not isinstance(item, dict):
            _print_error("Each assertion must be a mapping with 'label' and 'value'.")
            return
        label = item.get("label")
        value = item.get("value")
        if not label:
            _print_error("Assertion missing 'label'.")
            return
        # The C2PA library expects the assertion data to be placed under the key 'data'.
        converted_assertions.append({"label": label, "data": value})

    manifest_json: Dict[str, Any] = {
        "claim_generator": "OpenMediaTrust/c2pa_toolkit",
        "assertions": converted_assertions,
    }
    if title:
        manifest_json["title"] = title
    if creator:
        manifest_json["creator"] = creator

    # Read certificate and key for signing
    try:
        with open(cert_path, "rb") as cert_file, open(key_path, "rb") as key_file:
            cert_data = cert_file.read()
            key_data = key_file.read()
    except Exception as exc:
        _print_error(f"Failed to read certificate or key: {exc}")
        return

    # Construct signer information and signer
    try:
        signer_info = C2paSignerInfo(
            alg=C2paSigningAlg.PS256, cert=cert_data, key=key_data
        )
        signer = Signer.from_info(signer_info)
    except Exception as exc:
        _print_error(f"Failed to create signer: {exc}")
        return

    # Determine input MIME type for the c2pa builder
    mime_type = _infer_mime_type(input_path)

    try:
        with Builder(json.dumps(manifest_json)) as builder:
            with open(input_path, "rb") as src, open(output_path, "wb") as dst:
                # The sign method writes the signed file to dst and returns the
                # manifest bytes, which we ignore.
                builder.sign(signer, mime_type, src, dst)
        print(f"Signed file written to: {output_path}")
    except Exception as exc:
        _print_error(f"Failed to sign media: {exc}")


def main(argv: Optional[List[str]] = None) -> None:
    """Parse command‑line arguments and execute the requested command."""
    parser = argparse.ArgumentParser(
        description="OpenMediaTrust C2PA toolkit",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Verify subcommand
    verify_parser = subparsers.add_parser(
        "verify", help="Verify whether a file contains a C2PA manifest"
    )
    verify_parser.add_argument("file", help="Path to the media file to verify")

    # Report subcommand
    report_parser = subparsers.add_parser(
        "report", help="Generate a detailed JSON report of manifest data"
    )
    report_parser.add_argument("file", help="Path to the media file to inspect")

    # Sign subcommand
    sign_parser = subparsers.add_parser(
        "sign", help="Sign a media file with a new manifest"
    )
    sign_parser.add_argument(
        "--input", required=True, help="Path to the source media file"
    )
    sign_parser.add_argument(
        "--output", required=True, help="Path to write the signed output file"
    )
    sign_parser.add_argument(
        "--assertions",
        required=True,
        help="YAML file defining the manifest assertions (title, creator, assertions)",
    )
    sign_parser.add_argument(
        "--cert",
        required=True,
        help="Path to the PEM‑encoded signing certificate",
    )
    sign_parser.add_argument(
        "--key",
        required=True,
        help="Path to the PEM‑encoded private key corresponding to the certificate",
    )

    args = parser.parse_args(argv)

    if args.command == "verify":
        verify_media(args.file)
    elif args.command == "report":
        report_media(args.file)
    elif args.command == "sign":
        sign_media(args.input, args.output, args.assertions, args.cert, args.key)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()